import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Avatar {

    public void loadNewFxml(ActionEvent event) {
        try {
            Parent root1 = FXMLLoader.load(getClass().getResource("QueenGame.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("Queen");
            stage1.setResizable(false);
            stage1.setScene(new Scene(root1));
            stage1.show();
            MenuStarter.s().getScene().getWindow().hide();
        } catch (Exception e) {
            System.err.println("cant load the puzzle window");
        }

    }


    @FXML
    public Label myLabel;
    public javafx.scene.image.ImageView daqueen;
    public javafx.scene.image.ImageView branstark;
    public ImageView trump;

    public void intialize() {
        Image daqueenn = new Image("avatar/daqueen.jpg");
        daqueen.setImage(daqueenn);
    }

    public void intialize1() {
        Image branstarkk = new Image("avatar/branstark.jpg");
        branstark.setImage(branstarkk);
    }

    public void intialize2() {
        Image trumpp = new Image("avatar/trump.jpg");
        trump.setImage(trumpp);
    }

//buttons

    public static void backToMenu(ActionEvent click, Parent menu) {
        Scene menuView = new Scene(menu);
        Stage game = (Stage) ((Node) click.getSource()).getScene().getWindow();
        game.setScene(menuView);
        game.show();
    }


    @FXML
    public void exitbb(ActionEvent event) {
        try {

            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Menu.fxml"));

            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();
            // to close the previous window menu
            Node source = (Node) event.getSource();
            Stage stage2 = (Stage) source.getScene().getWindow();
            stage2.close();
        } catch (Exception e) {

        }
    }


//    public void startb(ActionEvent event) {
//        try {
//
//            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/sample/makeThings.fxml"));
//
//            Parent root1 = (Parent) fxmlLoader.load();
//            Stage stage = new Stage();
//            stage.setScene(new Scene(root1));
//            stage.show();
//            // to close the previous window menu
//            Node source = (Node) event.getSource();
//            Stage stage2 = (Stage) source.getScene().getWindow();
//            stage2.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }


    public void openGOT() {
        try {
            Parent root1 = FXMLLoader.load(getClass().getResource("BranStark.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("BranStark");
            stage1.setResizable(false);
            stage1.setScene(new Scene(root1));
            stage1.show();
            MenuStarter.s().getScene().getWindow().hide();
        } catch (Exception e) {
            System.err.println("cant load the puzzle window");
        }


    }

    public void openMexico(ActionEvent event) {
        try {
            Parent root1 = FXMLLoader.load(getClass().getResource("DTrump.fxml"));
            Stage stage1 = new Stage();
            stage1.setTitle("Donald Trump");
            stage1.setResizable(false);
            stage1.setScene(new Scene(root1));
            stage1.show();
            MenuStarter.s().getScene().getWindow().hide();
        } catch (Exception e) {
            System.err.println("cant load the puzzle window");
        }


    }


}