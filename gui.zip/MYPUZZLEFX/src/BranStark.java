
import javafx.concurrent.Task;
        import javafx.fxml.FXML;
        import javafx.fxml.FXMLLoader;
        import javafx.scene.Parent;
        import javafx.scene.Scene;
        import javafx.scene.control.*;
        import javafx.scene.image.Image;
        import javafx.scene.image.ImageView;
        import javafx.scene.layout.GridPane;
        import javafx.stage.Stage;

        import java.io.BufferedWriter;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.util.*;


public class BranStark {


    int move = 0;

    @FXML
    private Label moves, time;
    @FXML
    public Button restart;
    @FXML
    ToggleButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16;
    @FXML
    Image i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16;
    @FXML
    ImageView iv1, iv2, iv3, iv4, iv5, iv6, iv7, iv8, iv9, iv10, iv11, iv12, iv13, iv14, iv15, iv16;
    private Task<Integer> timer;
    @FXML
    List<ToggleButton> buttonsList;
    @FXML
    ImageView[] imageViewArray;
    @FXML
    List<Image> imageList;
    @FXML
    List<ImageView> imageViewList;
    @FXML
    GridPane gp;


    public ImageView[] generatePuzzle() {
        imageList = Arrays.asList(i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16);
        imageViewArray = new ImageView[]{iv1, iv2, iv3, iv4, iv5, iv6, iv7, iv8, iv9, iv10, iv11, iv12, iv13, iv14, iv15, iv16};
        imageViewList = Arrays.asList(imageViewArray);
        Collections.shuffle(imageViewList);
        for (int i = 0; i < imageViewArray.length; i++) {
            imageViewArray[i].setImage(imageList.get(i));
        }
        imageViewList.toArray(imageViewArray);
        return imageViewArray;
    }


    public void puzzleTimer() {
        timer = new Task<Integer>() {
            @Override
            protected Integer call() throws Exception {
                int value = 0;
                while (!isCancelled()) {
                    updateMessage("TIME: " + value);
                    value++;
                    Thread.sleep(1000);
                }
                return value;
            }
        };
        time.textProperty().bind(timer.messageProperty());
        Thread thread = new Thread(timer);
        thread.setDaemon(true);
        thread.start();
    }

    public void changeButton(ToggleButton button1, ToggleButton button2) {

        Image firstButtonImage = ((ImageView) button1.getGraphic()).getImage();
        Image secondButtonImage = ((ImageView) button2.getGraphic()).getImage();
        ((ImageView) button1.getGraphic()).setImage(secondButtonImage);
        ((ImageView) button2.getGraphic()).setImage(firstButtonImage);
        if (move == 0) {
            moves.setText("MOVES: 0");
        }
        move++;
        moves.setText("MOVES: " + move);
    }

    @FXML
    public void initialize() {
        puzzleTimer();
        generatePuzzle();
        click();


    }


    @FXML
    public void click() {
        int count = 1;

        buttonsList = Arrays.asList(b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15, b16);

        for (ToggleButton b : buttonsList) {
            b.setOnAction(e -> {
                for (ToggleButton b2 : buttonsList) {
                    //check if the button is clicked and it is not equal to the selected one
                    //check if the button is clicked and it is not equal to the selected one
                    if (b2.isSelected() && b2 != b) {
                        changeButton(b, b2);

                        if (checkWin()) {
                            stop();
                            try {
                                BufferedWriter fw = new BufferedWriter(new FileWriter("Results", true));
                                fw.write(moves.getText() + " " + time.getText() + "\n");
                                fw.close();

                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            Alert a = new Alert(Alert.AlertType.INFORMATION);
                            a.setTitle("congratulations!");
                            a.setHeaderText("YOU WIN:)");
                            a.setContentText("DO U WANT TO SEE THE RESULTS?");
                            // a.show();
                            a.getButtonTypes().clear();
                            ButtonType yes = new ButtonType("YES");
                            ButtonType no = new ButtonType("NO");
                            a.getButtonTypes().addAll(yes, no);
                            Optional<ButtonType> option = a.showAndWait();
                            //a.show();
                            if (option.get() == yes) {
                                showResultWindow();
                            } else {
                                a.close();
                            }


                        }

                        b.setSelected(false);
                        b2.setSelected(false);
                    }
                }
            });
        }

    }

    private boolean checkWin() {

        for (int i = 0; i < buttonsList.size(); i++) {
            ToggleButton button = buttonsList.get(i);
            ImageView imageView = (ImageView) button.getGraphic();

            if (!imageView.getImage().equals(imageList.get(i))) {
                return false;
            }
        }
        return true;


    }

    @FXML
    public void showResultWindow() {
        try {
            Parent root2 = FXMLLoader.load(getClass().getResource("Results.fxml"));
            Stage stage2 = new Stage();
            stage2.setTitle("RESULTS");
            stage2.setResizable(false);
            stage2.setScene(new Scene(root2, 400, 400));
            stage2.show();
        } catch (Exception e3) {
            e3.printStackTrace();
            // System.err.println("cant load the results window");
        }
    }

    @FXML
    public void restartButton() {
        puzzleTimer();
        generatePuzzle();
        move = 0;
        moves.setText("MOVES: 0");
    }

    @FXML
    public void stop() {
        timer.cancel();
    }
}