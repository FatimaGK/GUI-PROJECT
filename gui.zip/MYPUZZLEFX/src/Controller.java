import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Controller {


    public void getScore(){

    }

    @FXML
    public void backbb(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent root2 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("Back to Game");
            stage.setScene(new Scene(root2));
            stage.show();
            Node source = (Node) event.getSource();
            Stage stage2 = (Stage) source.getScene().getWindow();
            stage2.close();
        }catch (Exception e) {
            e.printStackTrace();
        }

    }

    @FXML

    public void playb(ActionEvent event) {
            try {
                Parent root1 = FXMLLoader.load(getClass().getResource("Avatar.fxml"));
                Stage stage1 = new Stage();
                stage1.setTitle("pUzZlE");
                stage1.setResizable(false);
                stage1.setScene(new Scene(root1));
                stage1.show();
                MenuStarter.s().getScene().getWindow().hide();
            } catch (Exception e) {
                System.err.println("cant load the puzzle window");
            }
    }


    @FXML
    public void exitb() {
        System.exit(0);
    }





    @FXML
    public void helpp(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("About.fxml"));
            Parent root2 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("About The Game");
            stage.setScene(new Scene(root2));
            stage.show();
        }catch (Exception e) {
            e.printStackTrace();
        }

    }




}