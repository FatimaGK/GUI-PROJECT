import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;


public class MenuStarter extends Application {

    static Stage stage;
    public static Stage s() {
        return stage;
    }

    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Menu.fxml"));
        Scene scene = new Scene(root);
        this.stage = stage;
        stage.setTitle("hi");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();


    }
}

