import javafx.fxml.FXML;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Results {
    @FXML
    TextArea text;
    @FXML
    ScrollBar scrollBar;
    ScrollPane root=new ScrollPane();

    public void resultInfo() throws IOException {
        text.setEditable(false);
        BufferedReader fileText = new BufferedReader(new FileReader("Results"));
        Scanner scanner = new Scanner(fileText);
        String line="";
        int lineNumber = 1;
        while (scanner.hasNextLine()) {
            line+= "[" + lineNumber + "] " + scanner.nextLine() + "\n";
            lineNumber++;

        }

        text.setWrapText(true);
        text.setText(line);
    }
    @FXML
    public void initialize() throws IOException {
        root.setContent(text);
        resultInfo();
    }
}
